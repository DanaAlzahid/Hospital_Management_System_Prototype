HMS_AI_Prototype - WinForms C# .NET 6 Prototype

How to open:
1. Requires .NET 6 SDK and Visual Studio 2022/2023 (or Visual Studio Code with C# extensions).
2. Open the solution file HMS_AI_Prototype.sln in Visual Studio.
3. Build and Run. Login with:
   Email: admin@hms.com
   Password: 1234

Notes:
- This is a prototype for demo/assignment only.
- The AI diet recommender is simulated with simple rules in code
