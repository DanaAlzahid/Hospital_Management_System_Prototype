using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace HMS_AI_Prototype
{
    public partial class PatientsForm : Form
    {
        

        public PatientsForm()
        {
            InitializeComponent();
           
        }

        private void btnViewProfile_Click(object sender, EventArgs e)
        {
         
        }
    }
}
