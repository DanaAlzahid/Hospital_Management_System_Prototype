namespace HMS_AI_Prototype
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnPatients;
        private System.Windows.Forms.Button btnDiet;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lblWelcome;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnPatients = new Button();
            btnDiet = new Button();
            btnLogout = new Button();
            lblWelcome = new Label();
            panel1 = new Panel();
            label1 = new Label();
            btnDashboard = new Button();
            btnRecords = new Button();
            panelMain = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnPatients
            // 
            btnPatients.BackColor = SystemColors.HighlightText;
            btnPatients.Location = new Point(12, 331);
            btnPatients.Name = "btnPatients";
            btnPatients.Size = new Size(196, 80);
            btnPatients.TabIndex = 0;
            btnPatients.Text = "Manage Patients";
            btnPatients.UseVisualStyleBackColor = false;
            btnPatients.Click += btnPatients_Click;
            // 
            // btnDiet
            // 
            btnDiet.BackColor = SystemColors.HighlightText;
            btnDiet.Location = new Point(12, 434);
            btnDiet.Name = "btnDiet";
            btnDiet.Size = new Size(196, 80);
            btnDiet.TabIndex = 1;
            btnDiet.Text = "Diet Recommendation";
            btnDiet.UseVisualStyleBackColor = false;
            btnDiet.Click += btnDiet_Click;
            // 
            // btnLogout
            // 
            btnLogout.BackColor = SystemColors.HighlightText;
            btnLogout.Location = new Point(12, 623);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(196, 39);
            btnLogout.TabIndex = 2;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Showcard Gothic", 28F, FontStyle.Bold, GraphicsUnit.Point);
            lblWelcome.Location = new Point(488, 24);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(530, 68);
            lblWelcome.TabIndex = 3;
            lblWelcome.Text = "Welcome to HMS ";
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.MenuHighlight;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(btnDashboard);
            panel1.Controls.Add(btnRecords);
            panel1.Controls.Add(btnPatients);
            panel1.Controls.Add(btnDiet);
            panel1.Controls.Add(btnLogout);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(226, 687);
            panel1.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(48, 33);
            label1.Name = "label1";
            label1.Size = new Size(102, 48);
            label1.TabIndex = 0;
            label1.Text = "HMS";
            // 
            // btnDashboard
            // 
            btnDashboard.BackColor = SystemColors.HighlightText;
            btnDashboard.Location = new Point(12, 129);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.Size = new Size(196, 80);
            btnDashboard.TabIndex = 0;
            btnDashboard.Text = "Dashboard";
            btnDashboard.UseVisualStyleBackColor = false;
            btnDashboard.Click += btnDashboard_Click;
            // 
            // btnRecords
            // 
            btnRecords.BackColor = SystemColors.HighlightText;
            btnRecords.Location = new Point(12, 234);
            btnRecords.Name = "btnRecords";
            btnRecords.Size = new Size(196, 80);
            btnRecords.TabIndex = 3;
            btnRecords.Text = "Medical Records";
            btnRecords.UseVisualStyleBackColor = false;
            btnRecords.Click += btnRecords_Click;
            // 
            // panelMain
            // 
            panelMain.BackColor = Color.PapayaWhip;
            panelMain.Dock = DockStyle.Fill;
            panelMain.Location = new Point(226, 0);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(1153, 687);
            panelMain.TabIndex = 5;
            // 
            // DashboardForm
            // 
            BackColor = Color.White;
            ClientSize = new Size(1379, 687);
            Controls.Add(panelMain);
            Controls.Add(panel1);
            Controls.Add(lblWelcome);
            Name = "DashboardForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "HMS APP";
            Load += DashboardForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private Panel panel1;
        private Button btnRecords;
        private Button btnDashboard;
        private Panel panelMain;
        private Label label1;
    }
}
