using System;
using System.Windows.Forms;

namespace HMS_AI_Prototype
{
    public partial class PatientProfileForm : Form
    {
      
        public PatientProfileForm()
        {
            InitializeComponent();
             
        }


        private void btnGenerateDiet_Click(object sender, EventArgs e)
        {
           
        }
    }
}
