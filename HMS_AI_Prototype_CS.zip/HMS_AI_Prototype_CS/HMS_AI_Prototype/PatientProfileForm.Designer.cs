namespace HMS_AI_Prototype
{
    partial class PatientProfileForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblCond;
        private System.Windows.Forms.Label lblAllergies;
        private System.Windows.Forms.Label lblBMI;
        private System.Windows.Forms.Button btnGenerateDiet;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblName = new Label();
            lblAge = new Label();
            lblCond = new Label();
            lblAllergies = new Label();
            lblBMI = new Label();
            btnGenerateDiet = new Button();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(24, 20);
            lblName.Name = "lblName";
            lblName.Size = new Size(0, 25);
            lblName.TabIndex = 0;
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.Location = new Point(24, 50);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(0, 25);
            lblAge.TabIndex = 1;
            // 
            // lblCond
            // 
            lblCond.AutoSize = true;
            lblCond.Location = new Point(24, 80);
            lblCond.Name = "lblCond";
            lblCond.Size = new Size(0, 25);
            lblCond.TabIndex = 2;
            // 
            // lblAllergies
            // 
            lblAllergies.AutoSize = true;
            lblAllergies.Location = new Point(24, 110);
            lblAllergies.Name = "lblAllergies";
            lblAllergies.Size = new Size(0, 25);
            lblAllergies.TabIndex = 3;
            // 
            // lblBMI
            // 
            lblBMI.AutoSize = true;
            lblBMI.Location = new Point(24, 140);
            lblBMI.Name = "lblBMI";
            lblBMI.Size = new Size(0, 25);
            lblBMI.TabIndex = 4;
            // 
            // btnGenerateDiet
            // 
            btnGenerateDiet.Location = new Point(12, 294);
            btnGenerateDiet.Name = "btnGenerateDiet";
            btnGenerateDiet.Size = new Size(114, 35);
            btnGenerateDiet.TabIndex = 5;
            btnGenerateDiet.Text = "Generate Diet";
            btnGenerateDiet.Click += btnGenerateDiet_Click;
            // 
            // PatientProfileForm
            // 
            ClientSize = new Size(602, 341);
            Controls.Add(lblName);
            Controls.Add(lblAge);
            Controls.Add(lblCond);
            Controls.Add(lblAllergies);
            Controls.Add(lblBMI);
            Controls.Add(btnGenerateDiet);
            Name = "PatientProfileForm";
            Text = "Patient Profile";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
