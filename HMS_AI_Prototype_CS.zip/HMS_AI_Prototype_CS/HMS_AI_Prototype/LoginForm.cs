using System;
using System.Windows.Forms;

namespace HMS_AI_Prototype
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var email = txtEmail.Text.Trim();
            var pass = txtPassword.Text.Trim();

            if (email == "admin" && pass == "1234")
            {
                var dash = new DashboardForm();
                dash.Show();
                this.Hide();
            }
            else
            {
                lblError.Text = "Invalid email or password.";
            }
        }
    }
}
