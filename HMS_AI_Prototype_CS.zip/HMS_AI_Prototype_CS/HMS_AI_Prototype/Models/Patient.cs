﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_AI_Prototype.Models
{
    public class Patient
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public double HeightCm { get; set; }
        public double WeightKg { get; set; }
        public string Allergies { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    }
}
