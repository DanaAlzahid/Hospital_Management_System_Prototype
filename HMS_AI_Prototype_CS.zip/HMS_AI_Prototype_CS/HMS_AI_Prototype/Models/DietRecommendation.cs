﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_AI_Prototype.Models
{
    public class DietRecommendation
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public DateTime CreatedAt { get; set; }
        public int Calories { get; set; }
        public string MacroTargets { get; set; } // e.g. "P:25,C:50,F:25"
        public string PlanText { get; set; } // simple text of meals
        public double Confidence { get; set; } // stub score
        public string Status { get; set; } // Draft, Approved
    }
}
