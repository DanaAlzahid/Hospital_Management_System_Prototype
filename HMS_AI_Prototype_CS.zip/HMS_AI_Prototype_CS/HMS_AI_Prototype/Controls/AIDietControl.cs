﻿using HMS_AI_Prototype.Data;
using HMS_AI_Prototype.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS_AI_Prototype.Controls
{
    public partial class AIDietControl : UserControl
    {
        public AIDietControl()
        {
            InitializeComponent();
            LoadPatients();
        }

        private void LoadPatients()
        {
            cmbPatients.DataSource = SeedData.Patients.ToList();
            cmbPatients.DisplayMember = "FullName";
            cmbPatients.ValueMember = "Id";
            cmbPatients.SelectedIndexChanged += cmbPatients_SelectedIndexChanged;
            if (cmbPatients.Items.Count > 0) cmbPatients.SelectedIndex = 0;
        }
        private double CalculateBMI(double heightCm, double weightKg)
        {
            var h = heightCm / 100.0;
            return weightKg / (h * h);
        }
        private void cmbPatients_SelectedIndexChanged(object sender, EventArgs e)
        {
            var p = cmbPatients.SelectedItem as Patient;
            if (p == null) return;
            lblHeight.Text = p.HeightCm.ToString();
            lblWeight.Text = p.WeightKg.ToString();
            lblBMI.Text = CalculateBMI(p.HeightCm, p.WeightKg).ToString("0.0");

        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            var p = cmbPatients.SelectedItem as Patient;
            if (p == null) return;
            // collect features
            string activity = cmbActivity.SelectedItem?.ToString() ?? "Moderate";
            double bmi = CalculateBMI(p.HeightCm, p.WeightKg);
            // simple calorie estimate using Mifflin-St Jeor (male/female simplified)
            int calories = EstimateCalories(p, activity);
            string macros = EstimateMacros(bmi, p);
            double confidence = 0.75 + (new Random().NextDouble() * 0.2); // stub

            // simple plan text
            var sb = new StringBuilder();
            sb.AppendLine($"Suggested Calories: {calories} kcal");
            sb.AppendLine($"Macro Targets: {macros}");
            sb.AppendLine($"Confidence: {confidence:0.00}");
            sb.AppendLine();
            sb.AppendLine("Sample Plan:");
            if (bmi >= 30)
            {
                sb.AppendLine("Breakfast: Oats + Skim Milk + Fruit");
                sb.AppendLine("Lunch: Grilled Chicken + Salad");
                sb.AppendLine("Snack: Yogurt");
                sb.AppendLine("Dinner: Steamed Fish + Veggies");
            }
            else if (bmi >= 25)
            {
                sb.AppendLine("Breakfast: Eggs + Whole-wheat Toast");
                sb.AppendLine("Lunch: Chickpea Salad + Olive Oil");
                sb.AppendLine("Dinner: Chicken + Vegetables");
            }
            else
            {
                sb.AppendLine("Breakfast: Paratha + Yogurt (if underweight, add calories)");
                sb.AppendLine("Lunch: Rice + Lentils + Chicken");
                sb.AppendLine("Dinner: Beef/Chicken + Vegetables");
            }

            txtPlan.Text = sb.ToString();
            // keep generated values in tag for saving
            txtPlan.Tag = new DietRecommendation
            {
                Id = SeedData.Diets.Count + 1,
                PatientId = p.Id,
                CreatedAt = DateTime.Now,
                Calories = calories,
                MacroTargets = macros,
                PlanText = sb.ToString(),
                Confidence = confidence,
                Status = confidence >= 0.75 ? "AutoSuggested" : "PendingReview"
            };
        }
        private int EstimateCalories(Patient p, string activity)
        {
            // very simple BMR + activity multiplier (stub)
            int age = DateTime.Now.Year - p.DOB.Year;
            double bmr;
            if (p.Gender?.ToLower().StartsWith("m") == true)
            {
                bmr = 10 * p.WeightKg + 6.25 * p.HeightCm - 5 * age + 5;
            }
            else
            {
                bmr = 10 * p.WeightKg + 6.25 * p.HeightCm - 5 * age - 161;
            }
            double mult = activity == "Low" ? 1.2 : activity == "High" ? 1.55 : 1.375;
            return (int)(bmr * mult);
        }

        private string EstimateMacros(double bmi, Patient p)
        {
            // simple macro suggestions
            if (bmi >= 30) return "P:30,C:40,F:30";
            if (bmi >= 25) return "P:28,C:45,F:27";
            return "P:22,C:55,F:23";
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            var draft = txtPlan.Tag as DietRecommendation;
            if (draft == null) { MessageBox.Show("Generate plan first."); return; }
            SeedData.Diets.Add(draft);
            MessageBox.Show("Diet draft saved.");
        }
    }
}
