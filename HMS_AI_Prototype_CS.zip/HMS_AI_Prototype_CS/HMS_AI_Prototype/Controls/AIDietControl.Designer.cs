﻿namespace HMS_AI_Prototype.Controls
{
    partial class AIDietControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label10 = new Label();
            cmbPatients = new ComboBox();
            label1 = new Label();
            lblHeight = new Label();
            lblWeight = new Label();
            lblBMI = new Label();
            cmbActivity = new ComboBox();
            txtPlan = new TextBox();
            btnGenerate = new Button();
            btnSave = new Button();
            SuspendLayout();
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = SystemColors.ActiveCaption;
            label10.Location = new Point(74, 39);
            label10.Name = "label10";
            label10.Size = new Size(595, 65);
            label10.TabIndex = 20;
            label10.Text = "AI Diet Recommendation";
            // 
            // cmbPatients
            // 
            cmbPatients.FormattingEnabled = true;
            cmbPatients.Location = new Point(35, 169);
            cmbPatients.Name = "cmbPatients";
            cmbPatients.Size = new Size(182, 33);
            cmbPatients.TabIndex = 22;
            cmbPatients.SelectedIndexChanged += cmbPatients_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(35, 131);
            label1.Name = "label1";
            label1.Size = new Size(124, 25);
            label1.TabIndex = 21;
            label1.Text = "Select Patients";
            // 
            // lblHeight
            // 
            lblHeight.AutoSize = true;
            lblHeight.Location = new Point(278, 172);
            lblHeight.Name = "lblHeight";
            lblHeight.Size = new Size(74, 25);
            lblHeight.TabIndex = 23;
            lblHeight.Text = "Height: ";
            // 
            // lblWeight
            // 
            lblWeight.AutoSize = true;
            lblWeight.Location = new Point(278, 221);
            lblWeight.Name = "lblWeight";
            lblWeight.Size = new Size(77, 25);
            lblWeight.TabIndex = 24;
            lblWeight.Text = "Weight: ";
            // 
            // lblBMI
            // 
            lblBMI.AutoSize = true;
            lblBMI.Location = new Point(278, 274);
            lblBMI.Name = "lblBMI";
            lblBMI.Size = new Size(47, 25);
            lblBMI.TabIndex = 25;
            lblBMI.Text = "BMI:";
            // 
            // cmbActivity
            // 
            cmbActivity.FormattingEnabled = true;
            cmbActivity.Items.AddRange(new object[] { "Low", "Moderate", "High" });
            cmbActivity.Location = new Point(278, 320);
            cmbActivity.Name = "cmbActivity";
            cmbActivity.Size = new Size(182, 33);
            cmbActivity.TabIndex = 26;
            // 
            // txtPlan
            // 
            txtPlan.Location = new Point(492, 320);
            txtPlan.Multiline = true;
            txtPlan.Name = "txtPlan";
            txtPlan.Size = new Size(241, 185);
            txtPlan.TabIndex = 27;
            // 
            // btnGenerate
            // 
            btnGenerate.Location = new Point(278, 411);
            btnGenerate.Name = "btnGenerate";
            btnGenerate.Size = new Size(182, 44);
            btnGenerate.TabIndex = 28;
            btnGenerate.Text = "Generate Plan";
            btnGenerate.UseVisualStyleBackColor = true;
            btnGenerate.Click += btnGenerate_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(278, 461);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(182, 44);
            btnSave.TabIndex = 29;
            btnSave.Text = "Save Draft";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // AIDietControl
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnSave);
            Controls.Add(btnGenerate);
            Controls.Add(txtPlan);
            Controls.Add(cmbActivity);
            Controls.Add(lblBMI);
            Controls.Add(lblWeight);
            Controls.Add(lblHeight);
            Controls.Add(cmbPatients);
            Controls.Add(label1);
            Controls.Add(label10);
            Name = "AIDietControl";
            Size = new Size(761, 533);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private ComboBox cmbPatients;
        private Label label1;
        private Label lblHeight;
        private Label lblWeight;
        private Label lblBMI;
        private ComboBox cmbActivity;
        private TextBox txtPlan;
        private Button btnGenerate;
        private Button btnSave;
    }
}
