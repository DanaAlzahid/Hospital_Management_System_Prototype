﻿using HMS_AI_Prototype.Data;
using HMS_AI_Prototype.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS_AI_Prototype.Controls
{
    public partial class PatientProfileControl : UserControl
    {
        public PatientProfileControl()
        {
            InitializeComponent();
            LoadPatientsList();
        }

        private void LoadPatientsList()
        {
            cmbPatients.DataSource = SeedData.Patients.ToList();
            cmbPatients.DisplayMember = "FullName";
            cmbPatients.ValueMember = "Id";
            if (cmbPatients.Items.Count > 0) cmbPatients.SelectedIndex = 0;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            var p = cmbPatients.SelectedItem as Patient;
            if (p == null) return;
            p.FullName = txtName.Text;
            p.DOB = dtpDOB.Value;
            p.Gender = txtGender.Text;
            p.HeightCm = (double)numHeight.Value;
            p.WeightKg = (double)numWeight.Value;
            p.Allergies = txtAllergies.Text;
            p.Phone = txtPhone.Text;
            p.Address = txtAddress.Text;
            MessageBox.Show("Patient updated.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadPatientsList(); // refresh list
        }

        private void cmbPatients_SelectedIndexChanged(object sender, EventArgs e)
        {
            var p = cmbPatients.SelectedItem as Patient;
            if (p == null) return;
            txtName.Text = p.FullName;
            dtpDOB.Value = p.DOB;
            txtGender.Text = p.Gender;
            numHeight.Value = (decimal)p.HeightCm;
            numWeight.Value = (decimal)p.WeightKg;
            txtAllergies.Text = p.Allergies;
            txtPhone.Text = p.Phone;
            txtAddress.Text = p.Address;
        }
    }
}
