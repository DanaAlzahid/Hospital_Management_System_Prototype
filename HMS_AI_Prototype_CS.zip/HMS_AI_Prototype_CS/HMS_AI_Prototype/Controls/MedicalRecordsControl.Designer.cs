﻿namespace HMS_AI_Prototype.Controls
{
    partial class MedicalRecordsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbPatients = new ComboBox();
            label1 = new Label();
            label10 = new Label();
            dgvRecords = new DataGridView();
            btnAddRecord = new Button();
            txtLabResults = new TextBox();
            label6 = new Label();
            txtDiagnosis = new TextBox();
            label5 = new Label();
            txtNotes = new TextBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvRecords).BeginInit();
            SuspendLayout();
            // 
            // cmbPatients
            // 
            cmbPatients.FormattingEnabled = true;
            cmbPatients.Location = new Point(16, 157);
            cmbPatients.Name = "cmbPatients";
            cmbPatients.Size = new Size(182, 33);
            cmbPatients.TabIndex = 3;
            cmbPatients.SelectedIndexChanged += cmbPatients_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 119);
            label1.Name = "label1";
            label1.Size = new Size(124, 25);
            label1.TabIndex = 2;
            label1.Text = "Select Patients";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = SystemColors.ActiveCaption;
            label10.Location = new Point(148, 25);
            label10.Name = "label10";
            label10.Size = new Size(402, 65);
            label10.TabIndex = 19;
            label10.Text = "Manage Records";
            // 
            // dgvRecords
            // 
            dgvRecords.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRecords.Location = new Point(259, 119);
            dgvRecords.Name = "dgvRecords";
            dgvRecords.RowHeadersWidth = 62;
            dgvRecords.RowTemplate.Height = 33;
            dgvRecords.Size = new Size(505, 225);
            dgvRecords.TabIndex = 20;
            // 
            // btnAddRecord
            // 
            btnAddRecord.Location = new Point(259, 572);
            btnAddRecord.Name = "btnAddRecord";
            btnAddRecord.Size = new Size(150, 34);
            btnAddRecord.TabIndex = 25;
            btnAddRecord.Text = "Add Record";
            btnAddRecord.UseVisualStyleBackColor = true;
            btnAddRecord.Click += btnAddRecord_Click;
            // 
            // txtLabResults
            // 
            txtLabResults.Location = new Point(394, 420);
            txtLabResults.Name = "txtLabResults";
            txtLabResults.Size = new Size(300, 31);
            txtLabResults.TabIndex = 24;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(257, 423);
            label6.Name = "label6";
            label6.Size = new Size(104, 25);
            label6.TabIndex = 23;
            label6.Text = "Lab Results:";
            // 
            // txtDiagnosis
            // 
            txtDiagnosis.Location = new Point(394, 370);
            txtDiagnosis.Name = "txtDiagnosis";
            txtDiagnosis.Size = new Size(300, 31);
            txtDiagnosis.TabIndex = 22;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(257, 373);
            label5.Name = "label5";
            label5.Size = new Size(94, 25);
            label5.TabIndex = 21;
            label5.Text = "Diagnosis:";
            // 
            // txtNotes
            // 
            txtNotes.Location = new Point(394, 473);
            txtNotes.Multiline = true;
            txtNotes.Name = "txtNotes";
            txtNotes.Size = new Size(300, 75);
            txtNotes.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(257, 476);
            label2.Name = "label2";
            label2.Size = new Size(63, 25);
            label2.TabIndex = 26;
            label2.Text = "Notes:";
            // 
            // MedicalRecordsControl
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(txtNotes);
            Controls.Add(label2);
            Controls.Add(btnAddRecord);
            Controls.Add(txtLabResults);
            Controls.Add(label6);
            Controls.Add(txtDiagnosis);
            Controls.Add(label5);
            Controls.Add(dgvRecords);
            Controls.Add(label10);
            Controls.Add(cmbPatients);
            Controls.Add(label1);
            Name = "MedicalRecordsControl";
            Size = new Size(790, 627);
            ((System.ComponentModel.ISupportInitialize)dgvRecords).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbPatients;
        private Label label1;
        private Label label10;
        private DataGridView dgvRecords;
        private Button btnAddRecord;
        private TextBox txtLabResults;
        private Label label6;
        private TextBox txtDiagnosis;
        private Label label5;
        private TextBox txtNotes;
        private Label label2;
    }
}
