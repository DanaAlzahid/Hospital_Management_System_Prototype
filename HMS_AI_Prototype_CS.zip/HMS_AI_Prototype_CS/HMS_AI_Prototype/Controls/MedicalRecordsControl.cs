﻿using HMS_AI_Prototype.Data;
using HMS_AI_Prototype.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS_AI_Prototype.Controls
{
    public partial class MedicalRecordsControl : UserControl
    {
        public MedicalRecordsControl()
        {
            InitializeComponent();
            LoadPatients();
        }

        private void LoadPatients()
        {
            cmbPatients.DataSource = SeedData.Patients.ToList();
            cmbPatients.DisplayMember = "FullName";
            cmbPatients.ValueMember = "Id";
            cmbPatients.SelectedIndexChanged += cmbPatients_SelectedIndexChanged;
            if (cmbPatients.Items.Count > 0) cmbPatients.SelectedIndex = 0;
        }
        private void btnAddRecord_Click(object sender, EventArgs e)
        {
            var p = cmbPatients.SelectedItem as Models.Patient;
            if (p == null) return;
            var newRec = new MedicalRecord
            {
                Id = SeedData.Records.Count + 1,
                PatientId = p.Id,
                RecordDate = DateTime.Now,
                Diagnosis = txtDiagnosis.Text,
                Notes = txtNotes.Text,
                LabResults = txtLabResults.Text
            };
            SeedData.Records.Add(newRec);
            LoadRecords();
            MessageBox.Show("Record added.");
        }
        private void LoadRecords()
        {
            var sel = cmbPatients.SelectedItem as Models.Patient;
            if (sel == null) return;
            var list = SeedData.Records.Where(r => r.PatientId == sel.Id)
                .Select(r => new { r.Id, r.RecordDate, r.Diagnosis, r.LabResults }).OrderByDescending(x => x.RecordDate).ToList();
            dgvRecords.DataSource = list;
        }
        private void cmbPatients_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadRecords();
        }
    }
}
