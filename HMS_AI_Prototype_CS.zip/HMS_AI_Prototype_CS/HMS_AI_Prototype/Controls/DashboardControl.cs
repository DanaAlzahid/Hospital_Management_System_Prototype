﻿using HMS_AI_Prototype.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS_AI_Prototype.Controls
{
    public partial class DashboardControl : UserControl
    {
        public DashboardControl()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            lblTotalPatients.Text = SeedData.Patients.Count.ToString();
            lblPendingDiet.Text = SeedData.Diets.Count(d => d.Status != "Approved").ToString();
            var recent = SeedData.Records.Where(r => (DateTime.Today - r.RecordDate).TotalDays <= 7).ToList();
            lblRecentRecords.Text = recent.Count.ToString();
            dgvPatients.DataSource = SeedData.Patients.Select(p => new { p.Id, p.FullName, Age = DateTime.Now.Year - p.DOB.Year }).ToList();
        }
    }
}
