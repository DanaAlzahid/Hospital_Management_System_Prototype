﻿namespace HMS_AI_Prototype.Controls
{
    partial class DashboardControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvPatients = new DataGridView();
            groupBox1 = new GroupBox();
            lblTotalPatients = new Label();
            groupBox2 = new GroupBox();
            lblPendingDiet = new Label();
            groupBox3 = new GroupBox();
            lblRecentRecords = new Label();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvPatients).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // dgvPatients
            // 
            dgvPatients.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPatients.Location = new Point(63, 117);
            dgvPatients.Name = "dgvPatients";
            dgvPatients.RowHeadersWidth = 62;
            dgvPatients.RowTemplate.Height = 33;
            dgvPatients.Size = new Size(689, 225);
            dgvPatients.TabIndex = 1;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblTotalPatients);
            groupBox1.Location = new Point(63, 366);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(168, 132);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Total Patients";
            // 
            // lblTotalPatients
            // 
            lblTotalPatients.AutoSize = true;
            lblTotalPatients.Location = new Point(23, 58);
            lblTotalPatients.Name = "lblTotalPatients";
            lblTotalPatients.Size = new Size(0, 25);
            lblTotalPatients.TabIndex = 1;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblPendingDiet);
            groupBox2.Location = new Point(263, 366);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(213, 132);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Pending Diet Requests";
            // 
            // lblPendingDiet
            // 
            lblPendingDiet.AutoSize = true;
            lblPendingDiet.Location = new Point(37, 58);
            lblPendingDiet.Name = "lblPendingDiet";
            lblPendingDiet.Size = new Size(0, 25);
            lblPendingDiet.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lblRecentRecords);
            groupBox3.Location = new Point(503, 366);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(249, 132);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Text = "Recent Records (last 7 days)";
            // 
            // lblRecentRecords
            // 
            lblRecentRecords.AutoSize = true;
            lblRecentRecords.Location = new Point(6, 58);
            lblRecentRecords.Name = "lblRecentRecords";
            lblRecentRecords.Size = new Size(0, 25);
            lblRecentRecords.TabIndex = 1;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = SystemColors.ActiveCaption;
            label10.Location = new Point(258, 20);
            label10.Name = "label10";
            label10.Size = new Size(273, 65);
            label10.TabIndex = 19;
            label10.Text = "Dashboard";
            // 
            // DashboardControl
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label10);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(dgvPatients);
            Name = "DashboardControl";
            Size = new Size(810, 580);
            ((System.ComponentModel.ISupportInitialize)dgvPatients).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dgvPatients;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Label lblTotalPatients;
        private Label lblPendingDiet;
        private Label lblRecentRecords;
        private Label label10;
    }
}
