﻿namespace HMS_AI_Prototype.Controls
{
    partial class PatientProfileControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            cmbPatients = new ComboBox();
            label2 = new Label();
            txtName = new TextBox();
            txtGender = new TextBox();
            label3 = new Label();
            txtAllergies = new TextBox();
            label4 = new Label();
            txtPhone = new TextBox();
            label5 = new Label();
            txtAddress = new TextBox();
            label6 = new Label();
            label7 = new Label();
            dtpDOB = new DateTimePicker();
            numHeight = new NumericUpDown();
            label8 = new Label();
            label9 = new Label();
            numWeight = new NumericUpDown();
            label10 = new Label();
            btnSave = new Button();
            ((System.ComponentModel.ISupportInitialize)numHeight).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numWeight).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 143);
            label1.Name = "label1";
            label1.Size = new Size(124, 25);
            label1.TabIndex = 0;
            label1.Text = "Select Patients";
            // 
            // cmbPatients
            // 
            cmbPatients.FormattingEnabled = true;
            cmbPatients.Location = new Point(31, 181);
            cmbPatients.Name = "cmbPatients";
            cmbPatients.Size = new Size(182, 33);
            cmbPatients.TabIndex = 1;
            cmbPatients.SelectedIndexChanged += cmbPatients_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(308, 137);
            label2.Name = "label2";
            label2.Size = new Size(95, 25);
            label2.TabIndex = 2;
            label2.Text = "Full Name:";
            // 
            // txtName
            // 
            txtName.Location = new Point(445, 134);
            txtName.Name = "txtName";
            txtName.Size = new Size(300, 31);
            txtName.TabIndex = 3;
            // 
            // txtGender
            // 
            txtGender.Location = new Point(445, 229);
            txtGender.Name = "txtGender";
            txtGender.Size = new Size(300, 31);
            txtGender.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(307, 232);
            label3.Name = "label3";
            label3.Size = new Size(73, 25);
            label3.TabIndex = 4;
            label3.Text = "Gender:";
            // 
            // txtAllergies
            // 
            txtAllergies.Location = new Point(445, 378);
            txtAllergies.Name = "txtAllergies";
            txtAllergies.Size = new Size(300, 31);
            txtAllergies.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(308, 381);
            label4.Name = "label4";
            label4.Size = new Size(83, 25);
            label4.TabIndex = 6;
            label4.Text = "Allergies:";
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(445, 428);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(300, 31);
            txtPhone.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(308, 431);
            label5.Name = "label5";
            label5.Size = new Size(66, 25);
            label5.TabIndex = 8;
            label5.Text = "Phone:";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(445, 478);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(300, 31);
            txtAddress.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(308, 481);
            label6.Name = "label6";
            label6.Size = new Size(86, 25);
            label6.TabIndex = 10;
            label6.Text = "Address: ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(308, 186);
            label7.Name = "label7";
            label7.Size = new Size(116, 25);
            label7.TabIndex = 12;
            label7.Text = "Date of Birth:";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // dtpDOB
            // 
            dtpDOB.Location = new Point(445, 183);
            dtpDOB.Name = "dtpDOB";
            dtpDOB.Size = new Size(300, 31);
            dtpDOB.TabIndex = 13;
            // 
            // numHeight
            // 
            numHeight.Location = new Point(445, 277);
            numHeight.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numHeight.Name = "numHeight";
            numHeight.Size = new Size(300, 31);
            numHeight.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(308, 283);
            label8.Name = "label8";
            label8.Size = new Size(69, 25);
            label8.TabIndex = 15;
            label8.Text = "Height:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(308, 335);
            label9.Name = "label9";
            label9.Size = new Size(72, 25);
            label9.TabIndex = 17;
            label9.Text = "Weight:";
            // 
            // numWeight
            // 
            numWeight.Location = new Point(445, 329);
            numWeight.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numWeight.Name = "numWeight";
            numWeight.Size = new Size(300, 31);
            numWeight.TabIndex = 16;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = SystemColors.ActiveCaption;
            label10.Location = new Point(175, 34);
            label10.Name = "label10";
            label10.Size = new Size(480, 65);
            label10.TabIndex = 18;
            label10.Text = "Patient Profile Form";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(312, 558);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(91, 34);
            btnSave.TabIndex = 19;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // PatientProfileControl
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnSave);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(numWeight);
            Controls.Add(label8);
            Controls.Add(numHeight);
            Controls.Add(dtpDOB);
            Controls.Add(label7);
            Controls.Add(txtAddress);
            Controls.Add(label6);
            Controls.Add(txtPhone);
            Controls.Add(label5);
            Controls.Add(txtAllergies);
            Controls.Add(label4);
            Controls.Add(txtGender);
            Controls.Add(label3);
            Controls.Add(txtName);
            Controls.Add(label2);
            Controls.Add(cmbPatients);
            Controls.Add(label1);
            Name = "PatientProfileControl";
            Size = new Size(854, 728);
            ((System.ComponentModel.ISupportInitialize)numHeight).EndInit();
            ((System.ComponentModel.ISupportInitialize)numWeight).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ComboBox cmbPatients;
        private Label label2;
        private TextBox txtName;
        private TextBox txtGender;
        private Label label3;
        private TextBox txtAllergies;
        private Label label4;
        private TextBox txtPhone;
        private Label label5;
        private TextBox txtAddress;
        private Label label6;
        private Label label7;
        private DateTimePicker dtpDOB;
        private NumericUpDown numHeight;
        private Label label8;
        private Label label9;
        private NumericUpDown numWeight;
        private Label label10;
        private Button btnSave;
    }
}
