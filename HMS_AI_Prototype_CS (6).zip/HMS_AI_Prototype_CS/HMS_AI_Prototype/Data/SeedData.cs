﻿using HMS_AI_Prototype.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace HMS_AI_Prototype.Data
{
    public static class SeedData
    {
        public static List<Patient> Patients = new List<Patient> {
            new Patient { Id = 1, FullName = "Fahad Al-Mutairi", DOB = new DateTime(1990,5,12), Gender = "Male", HeightCm = 175, WeightKg = 78, Allergies = "None", Phone="05001234567", Address="Jeddah" },
            new Patient { Id = 2, FullName = "Sara Al-Salem", DOB = new DateTime(1985,3,2), Gender = "Female", HeightCm = 160, WeightKg = 68, Allergies = "Peanuts", Phone="05007654321", Address="Jeddah" }
        };

        public static List<MedicalRecord> Records = new List<MedicalRecord> {
            new MedicalRecord { Id = 1, PatientId = 1, RecordDate = DateTime.Today.AddDays(-30), Diagnosis = "Hypertension", Notes="On medication", LabResults="BP:140/90" },
            new MedicalRecord { Id = 2, PatientId = 2, RecordDate = DateTime.Today.AddDays(-10), Diagnosis = "Iron deficiency", Notes="Supplements advised", LabResults="Hb:10.2" }
        };

        public static List<DietRecommendation> Diets = new List<DietRecommendation> {
            new DietRecommendation { Id = 1, PatientId = 1, CreatedAt = DateTime.Today.AddDays(-7), Calories = 2200, MacroTargets = "P:25,C:50,F:25", PlanText = "Breakfast: Oats\nLunch: Chicken+Salad\nDinner: Fish+Veg", Confidence = 0.85, Status="Approved" }
        };
    }
}
