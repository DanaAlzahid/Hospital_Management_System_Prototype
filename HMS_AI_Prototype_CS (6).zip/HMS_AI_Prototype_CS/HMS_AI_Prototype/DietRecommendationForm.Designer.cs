namespace HMS_AI_Prototype
{
    partial class DietRecommendationForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblPatientName;
        private System.Windows.Forms.Label lblPlanType;
        private System.Windows.Forms.TextBox txtMeals;
        private System.Windows.Forms.Label lblNotes;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblPatientName = new System.Windows.Forms.Label();
            this.lblPlanType = new System.Windows.Forms.Label();
            this.txtMeals = new System.Windows.Forms.TextBox();
            this.lblNotes = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPatientName
            // 
            this.lblPatientName.Location = new System.Drawing.Point(24, 20);
            this.lblPatientName.AutoSize = true;
            // 
            // lblPlanType
            // 
            this.lblPlanType.Location = new System.Drawing.Point(24, 50);
            this.lblPlanType.AutoSize = true;
            // 
            // txtMeals
            // 
            this.txtMeals.Location = new System.Drawing.Point(24, 80);
            this.txtMeals.Multiline = true;
            this.txtMeals.Size = new System.Drawing.Size(360, 120);
            // 
            // lblNotes
            // 
            this.lblNotes.Location = new System.Drawing.Point(24, 210);
            this.lblNotes.AutoSize = true;
            // 
            // DietRecommendationForm
            // 
            this.ClientSize = new System.Drawing.Size(420, 260);
            this.Controls.Add(this.lblPatientName);
            this.Controls.Add(this.lblPlanType);
            this.Controls.Add(this.txtMeals);
            this.Controls.Add(this.lblNotes);
            this.Text = "Diet Recommendation";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
