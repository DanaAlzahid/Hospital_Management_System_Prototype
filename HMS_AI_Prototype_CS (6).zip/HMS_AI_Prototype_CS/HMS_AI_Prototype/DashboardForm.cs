using HMS_AI_Prototype.Controls;
using System;
using System.Windows.Forms;

namespace HMS_AI_Prototype
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
        }

        //private void btnPatients_Click(object sender, EventArgs e)
        //{
        //    var pf = new PatientsForm();
        //    pf.Show();
        //}

        //private void btnDiet_Click(object sender, EventArgs e)
        //{
        //    var df = new DietRecommendationForm();
        //    df.Show();
        //}

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {

            // show dashboard initially
            ShowControl(new DashboardControl());
        }

        private void ShowControl(UserControl uc)
        {
            panelMain.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            panelMain.Controls.Add(uc);
        }
        private void btnDashboard_Click(object sender, EventArgs e) => ShowControl(new DashboardControl());
        private void btnPatients_Click(object sender, EventArgs e) => ShowControl(new PatientProfileControl());
        private void btnRecords_Click(object sender, EventArgs e) => ShowControl(new MedicalRecordsControl());
        private void btnDiet_Click(object sender, EventArgs e) => ShowControl(new AIDietControl());

        private void btnDiet_Click_1(object sender, EventArgs e)
        {

        }

        private void btnPatients_Click_1(object sender, EventArgs e)
        {

        }

        private void btnRecords_Click_1(object sender, EventArgs e)
        {

        }

        private void btnDashboard_Click_1(object sender, EventArgs e)
        {

        }
    }
}
