namespace HMS_AI_Prototype
{
    partial class PatientsForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvPatients;
        private System.Windows.Forms.Button btnViewProfile;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dgvPatients = new DataGridView();
            btnViewProfile = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvPatients).BeginInit();
            SuspendLayout();
            // 
            // dgvPatients
            // 
            dgvPatients.ColumnHeadersHeight = 34;
            dgvPatients.Location = new Point(12, 24);
            dgvPatients.Name = "dgvPatients";
            dgvPatients.RowHeadersWidth = 62;
            dgvPatients.Size = new Size(633, 200);
            dgvPatients.TabIndex = 0;
            // 
            // btnViewProfile
            // 
            btnViewProfile.Location = new Point(559, 247);
            btnViewProfile.Name = "btnViewProfile";
            btnViewProfile.Size = new Size(86, 36);
            btnViewProfile.TabIndex = 1;
            btnViewProfile.Text = "View Profile";
            btnViewProfile.Click += btnViewProfile_Click;
            // 
            // PatientsForm
            // 
            ClientSize = new Size(673, 296);
            Controls.Add(dgvPatients);
            Controls.Add(btnViewProfile);
            Name = "PatientsForm";
            Text = "Patients";
            ((System.ComponentModel.ISupportInitialize)dgvPatients).EndInit();
            ResumeLayout(false);
        }
    }
}
