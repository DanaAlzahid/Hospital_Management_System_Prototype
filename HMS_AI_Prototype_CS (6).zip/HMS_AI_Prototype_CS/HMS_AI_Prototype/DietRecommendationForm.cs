using System;
using System.Windows.Forms;

namespace HMS_AI_Prototype
{
    public partial class DietRecommendationForm : Form
    {
    
        public DietRecommendationForm()
        {
            InitializeComponent();
        }

      

       
    }
}
